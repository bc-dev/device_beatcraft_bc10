#!/system/bin/sh

netcfg eth0 up
netcfg eth0 dhcp

/gps_init.sh

